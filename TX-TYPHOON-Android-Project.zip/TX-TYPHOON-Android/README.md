# TX TYPHOON Android App

A simple Android WebView wrapper for the TX TYPHOON gaming site. The website is bundled locally in `app/src/main/assets/index.html`, so the app can open the included pages without a web server.

## Build an APK with GitHub Actions (phone-friendly)

1. Create a GitHub repository named `TX-TYPHOON-Android`.
2. Upload the contents of this folder to the repository's `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build TX TYPHOON APK** and tap **Run workflow** (or wait for the first push build).
5. When the workflow finishes, open the run and download the `TX-TYPHOON-debug-APK` artifact.
6. Extract the ZIP artifact to find `app-debug.apk`.

This is a debug APK for testing. For public distribution, create and protect a release signing key and build a signed release APK. Never share your signing key or passwords.

## Build locally

Open this folder in Android Studio and build the `app` module, or run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Current limitations

- Login/profile is a local demo profile saved in the WebView browser storage; it is not a secure online account system.
- Tournament interest and rewards are demo UI only; they do not submit to a server or grant real prizes.
- Contact opens the device email app. Add a real contact address before publishing.
- The app currently bundles the HTML site. Website changes need to be copied into `app/src/main/assets/index.html` and a new APK built.
